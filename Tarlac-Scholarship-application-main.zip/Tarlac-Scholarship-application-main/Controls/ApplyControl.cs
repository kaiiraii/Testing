using System.Windows.Forms;
using scholarship_Application.Models;
using scholarship_Application.Services;

namespace scholarship_Application.Controls
{
    public partial class ApplyControl : UserControl, IRefreshable
    {
        public ApplyControl()
        {
            InitializeComponent();

            nudIncome.Maximum = 10000000;

            cboProgram.Items.AddRange(new object[] { "Merit", "Need-based", "General" });

            txtFullName.Text = Session.FullName;
            txtStudentNumber.Text = Session.StudentNumber;

            if (Session.CurrentUser != null)
            {
                txtEmail.Text = Session.CurrentUser.Email;
            }
            else
            {
                txtEmail.Text = "";
            }
        }

        private void cboProgram_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblHint.Text = cboProgram.SelectedIndex switch
            {
                0 => "Merit - GWA of at least 3.50. Award up to PHP 50,000.",
                1 => "Need-based - household income of at most PHP 400,000 per year. Award up to PHP 80,000.",
                2 => "General - GWA of at least 2.50 and income of at most PHP 600,000 per year. Award PHP 20,000.",
                _ => "Select a scholarship program to see its eligibility rule.",
            };
        }

        private void btnPhoto_Click(object sender, EventArgs e)
        {
            if (ofdPhoto.ShowDialog() != DialogResult.OK)
            {
                return;
            }

            try
            {
                picPhoto.Image?.Dispose();
                picPhoto.Image = Image.FromFile(ofdPhoto.FileName);
            }
            catch
            {
                MessageBox.Show("That file is not a valid image.",
                    "Invalid picture", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (cboProgram.SelectedItem is not string program)
            {
                MessageBox.Show("Select a scholarship program first.",
                    "Missing program", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cboProgram.Focus();
                return;
            }

            ScholarshipApplication? existing = SampleData.Applications.FirstOrDefault(a =>
                a.StudentNumber == Session.StudentNumber &&
                a.ScholarshipType == program &&
                a.Status != "Rejected");

            if (existing is not null)
            {
                MessageBox.Show(
                    $"You already have a {program} application (status: {existing.Status}).\n" +
                    "You can apply to this program again only if that application is rejected.",
                    "Already applied",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return;
            }

            var application = new ScholarshipApplication
            {
                StudentNumber = Session.StudentNumber,
                FullName = Session.FullName,
                Email = string.IsNullOrWhiteSpace(txtEmail.Text)
                    ? Session.CurrentUser?.Email ?? ""
                    : txtEmail.Text.Trim(),
                ScholarshipType = program,
                Gpa = nudGwa.Value,
                AnnualIncome = nudIncome.Value,
                Status = "Submitted",
                Remarks = "",
                SubmittedAt = DateTime.Now,
                Photo = picPhoto.Image is null ? null : new Bitmap(picPhoto.Image),
            };

            SampleData.Applications.Add(application);
            RefreshData();

            MessageBox.Show(
                "Thank you! Your application has been submitted for review.\n" +
                "The scholarship office will update your status.",
                "Application submitted",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);

            ClearForm();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void ClearForm()
        {
            txtEmail.Text = Session.CurrentUser?.Email ?? "";
            cboProgram.SelectedIndex = -1;
            nudGwa.Value = nudGwa.Minimum;
            nudIncome.Value = 0;
            lblHint.Text = "Select a scholarship program to see its eligibility rule.";
            picPhoto.Image?.Dispose();
            picPhoto.Image = null;
            txtEmail.Focus();
        }

        public void RefreshData()
        {
            lstMine.Items.Clear();
            foreach (ScholarshipApplication app in SampleData.Applications
                .Where(a => a.StudentNumber == Session.StudentNumber)
                .OrderByDescending(a => a.SubmittedAt))
            {
                lstMine.Items.Add(app.Display);
            }
        }

        protected override void OnVisibleChanged(EventArgs e)
        {
            base.OnVisibleChanged(e);
            if (Visible)
            {
                RefreshData();
            }
        }
    }
}

