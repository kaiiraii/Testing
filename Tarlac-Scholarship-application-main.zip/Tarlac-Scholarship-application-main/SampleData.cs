using scholarship_Application.Models;

namespace scholarship_Application
{
    public static class SampleData
    {
        public static readonly List<ScholarshipApplication> Applications = new();
    }
}
