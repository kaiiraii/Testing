﻿using scholarship_Application.Services;

namespace scholarship_Application.Forms
{
    public partial class SignUpForm : Form
    {
        public string CreatedUsername { get; private set; } = "";

        public SignUpForm()
        {
            InitializeComponent();
        }

        private void btnCreateAccount_Click(object? sender, EventArgs e)
        {
            lblError.Text = "";

            RegisterResult result = AuthService.Register(
                txtFullName.Text,
                txtStudentNumber.Text,
                txtUsername.Text,
                txtEmail.Text,
                txtPassword.Text,
                txtConfirmPassword.Text);

            if (!result.Success)
            {
                lblError.Text = result.Message;
                FocusField(result.Field);
                return;
            }

            CreatedUsername = txtUsername.Text.Trim();

            MessageBox.Show(
                "Account created. You can now sign in.",
                "Sign up",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);

            DialogResult = DialogResult.OK;
        }

        private void chkShowPassword_CheckedChanged(object? sender, EventArgs e)
        {
            txtPassword.UseSystemPasswordChar = !chkShowPassword.Checked;
            txtConfirmPassword.UseSystemPasswordChar = !chkShowPassword.Checked;
        }

        private void lnkSignIn_LinkClicked(object? sender, LinkLabelLinkClickedEventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void FocusField(string field)
        {
            TextBox? target = field switch
            {
                "FullName" => txtFullName,
                "StudentNumber" => txtStudentNumber,
                "Username" => txtUsername,
                "Email" => txtEmail,
                "Password" => txtPassword,
                "Confirm" => txtConfirmPassword,
                _ => null,
            };

            target?.Focus();
            target?.SelectAll();
        }
    }
}
