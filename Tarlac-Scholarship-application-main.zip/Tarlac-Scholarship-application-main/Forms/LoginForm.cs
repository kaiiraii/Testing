﻿
using scholarship_Application.Models;
using scholarship_Application.Services;

namespace scholarship_Application.Forms
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void LoginForm_Load(object? sender, EventArgs e)
        {
            txtUsername.SelectAll();
            txtUsername.Focus();
        }

        private void chkShow_CheckedChanged(object? sender, EventArgs e)
        {
            txtPassword.UseSystemPasswordChar = !chkShow.Checked;
        }

        private void btnSignIn_Click(object? sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            if (username.Length == 0)
            {
                lblError.Text = "Type your username or email to continue.";
                txtUsername.Focus();
                return;
            }

            if (txtPassword.Text.Length == 0)
            {
                lblError.Text = "Type your password to continue.";
                txtPassword.Focus();
                return;
            }

            UserAccount? user = AuthService.SignIn(username, txtPassword.Text);
            if (user is null)
            {
                lblError.Text = "Incorrect username or password.";
                txtPassword.Clear();
                txtPassword.Focus();
                return;
            }

            DashboardBase shell;

            if (user.Role == Roles.Admin)
            {
                shell = new AdminDashboard(this);
            }
            else
            {
                shell = new StudentDashboard(this);
            }

            shell.FormClosed += (_, _) =>
            {
                if (!IsDisposed && !Visible)
                {
                    Application.Exit();
                }
            };

            Hide();
            shell.Show();

            txtPassword.Clear();
            lblError.Text = "";
        }

        private void lnkCreateAccount_LinkClicked(object? sender, LinkLabelLinkClickedEventArgs e)
        {
            using var signUp = new SignUpForm();
            if (signUp.ShowDialog(this) == DialogResult.OK)
            {
                txtUsername.Text = signUp.CreatedUsername;
                txtPassword.Clear();
                lblError.Text = "";
                txtPassword.Focus();
            }
        }

        public void Reset()
        {
            AuthService.SignOut();
            Show();
            txtPassword.Clear();
            lblError.Text = "";
            txtUsername.SelectAll();
            txtUsername.Focus();
        }
    }
}
