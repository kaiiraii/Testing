using scholarship_Application.Controls;
using scholarship_Application.Services;

namespace scholarship_Application.Forms
{
    public partial class AdminDashboard : DashboardBase
    {
        private readonly LoginForm _login;

        public AdminDashboard(LoginForm login)
        {
            InitializeComponent();
            _login = login;
            RegisterNav(btnDashboard, btnApplications);

            lblUserChip.Text = $"Signed in as\n{Session.FullName}";
        }

        private void AdminDashboard_Load(object sender, EventArgs e)
        {
            Activate(btnDashboard, new AdminHomeControl());
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            Activate(btnDashboard, new AdminHomeControl());
        }

        private void btnApplications_Click(object sender, EventArgs e)
        {
            Activate(btnApplications, new AdminApplicationsControl());
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            if (LogoutTo(_login))
            {
                _login.Reset();
            }
        }
    }
}
