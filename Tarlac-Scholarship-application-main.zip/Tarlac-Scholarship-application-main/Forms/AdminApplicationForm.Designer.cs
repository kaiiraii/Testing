﻿using scholarship_Application.Models;

namespace scholarship_Application.Forms
{
    partial class AdminApplicationForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }


        private void InitializeComponent()
        {
            lblTitle = new Label();
            lblName = new Label();
            txtFullName = new TextBox();
            lblStudentNumber = new Label();
            txtStudentNumber = new TextBox();
            lblEmail = new Label();
            txtEmail = new TextBox();
            lblProgram = new Label();
            cboProgram = new ComboBox();
            lblGwa = new Label();
            nudGwa = new NumericUpDown();
            lblIncome = new Label();
            nudIncome = new NumericUpDown();
            lblPeso = new Label();
            btnCreate = new Button();
            btnCancel = new Button();
            lblPhotoTitle = new Label();
            picPhoto = new PictureBox();
            btnPhoto = new Button();
            ofdPhoto = new OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)nudGwa).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudIncome).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picPhoto).BeginInit();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI Semibold", 13F);
            lblTitle.ForeColor = Color.FromArgb(24, 41, 74);
            lblTitle.Location = new Point(18, 12);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(147, 25);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "New application";
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Font = new Font("Segoe UI Semibold", 9.25F);
            lblName.ForeColor = Color.FromArgb(45, 52, 66);
            lblName.Location = new Point(18, 45);
            lblName.Name = "lblName";
            lblName.Size = new Size(67, 17);
            lblName.TabIndex = 1;
            lblName.Text = "Full name";
            // 
            // txtFullName
            // 
            txtFullName.Font = new Font("Segoe UI", 10.5F);
            txtFullName.Location = new Point(18, 62);
            txtFullName.Margin = new Padding(3, 2, 3, 2);
            txtFullName.Name = "txtFullName";
            txtFullName.Size = new Size(298, 26);
            txtFullName.TabIndex = 2;
            // 
            // lblStudentNumber
            // 
            lblStudentNumber.AutoSize = true;
            lblStudentNumber.Font = new Font("Segoe UI Semibold", 9.25F);
            lblStudentNumber.ForeColor = Color.FromArgb(45, 52, 66);
            lblStudentNumber.Location = new Point(18, 92);
            lblStudentNumber.Name = "lblStudentNumber";
            lblStudentNumber.Size = new Size(108, 17);
            lblStudentNumber.TabIndex = 3;
            lblStudentNumber.Text = "Student number";
            // 
            // txtStudentNumber
            // 
            txtStudentNumber.Font = new Font("Segoe UI", 10.5F);
            txtStudentNumber.Location = new Point(18, 108);
            txtStudentNumber.Margin = new Padding(3, 2, 3, 2);
            txtStudentNumber.Name = "txtStudentNumber";
            txtStudentNumber.Size = new Size(298, 26);
            txtStudentNumber.TabIndex = 4;
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Font = new Font("Segoe UI Semibold", 9.25F);
            lblEmail.ForeColor = Color.FromArgb(45, 52, 66);
            lblEmail.Location = new Point(18, 138);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(40, 17);
            lblEmail.TabIndex = 5;
            lblEmail.Text = "Email";
            // 
            // txtEmail
            // 
            txtEmail.Font = new Font("Segoe UI", 10.5F);
            txtEmail.Location = new Point(18, 154);
            txtEmail.Margin = new Padding(3, 2, 3, 2);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(298, 26);
            txtEmail.TabIndex = 6;
            // 
            // lblProgram
            // 
            lblProgram.AutoSize = true;
            lblProgram.Font = new Font("Segoe UI Semibold", 9.25F);
            lblProgram.ForeColor = Color.FromArgb(45, 52, 66);
            lblProgram.Location = new Point(18, 184);
            lblProgram.Name = "lblProgram";
            lblProgram.Size = new Size(134, 17);
            lblProgram.TabIndex = 7;
            lblProgram.Text = "Scholarship program";
            // 
            // cboProgram
            // 
            cboProgram.DropDownStyle = ComboBoxStyle.DropDownList;
            cboProgram.Font = new Font("Segoe UI", 10.5F);
            cboProgram.FormattingEnabled = true;
            cboProgram.Items.AddRange(new object[] { "Merit", "Need-based", "General" });
            cboProgram.Location = new Point(18, 201);
            cboProgram.Margin = new Padding(3, 2, 3, 2);
            cboProgram.Name = "cboProgram";
            cboProgram.Size = new Size(298, 27);
            cboProgram.TabIndex = 8;
            // 
            // lblGwa
            // 
            lblGwa.AutoSize = true;
            lblGwa.Font = new Font("Segoe UI Semibold", 9.25F);
            lblGwa.ForeColor = Color.FromArgb(45, 52, 66);
            lblGwa.Location = new Point(18, 230);
            lblGwa.Name = "lblGwa";
            lblGwa.Size = new Size(98, 17);
            lblGwa.TabIndex = 9;
            lblGwa.Text = "GWA (0.0 - 4.0)";
            // 
            // nudGwa
            // 
            nudGwa.DecimalPlaces = 2;
            nudGwa.Font = new Font("Segoe UI", 10.5F);
            nudGwa.Increment = new decimal(new int[] { 5, 0, 0, 131072 });
            nudGwa.Location = new Point(18, 246);
            nudGwa.Margin = new Padding(3, 2, 3, 2);
            nudGwa.Maximum = new decimal(new int[] { 4, 0, 0, 0 });
            nudGwa.Name = "nudGwa";
            nudGwa.Size = new Size(105, 26);
            nudGwa.TabIndex = 10;
            // 
            // lblIncome
            // 
            lblIncome.AutoSize = true;
            lblIncome.Font = new Font("Segoe UI Semibold", 9.25F);
            lblIncome.ForeColor = Color.FromArgb(45, 52, 66);
            lblIncome.Location = new Point(144, 230);
            lblIncome.Name = "lblIncome";
            lblIncome.Size = new Size(147, 17);
            lblIncome.TabIndex = 11;
            lblIncome.Text = "Household income / yr";
            // 
            // nudIncome
            // 
            nudIncome.Font = new Font("Segoe UI", 10.5F);
            nudIncome.Increment = new decimal(new int[] { 10000, 0, 0, 0 });
            nudIncome.Location = new Point(144, 246);
            nudIncome.Margin = new Padding(3, 2, 3, 2);
            nudIncome.Name = "nudIncome";
            nudIncome.Size = new Size(140, 26);
            nudIncome.TabIndex = 12;
            nudIncome.ThousandsSeparator = true;
            nudIncome.ValueChanged += nudIncome_ValueChanged;
            // 
            // lblPeso
            // 
            lblPeso.AutoSize = true;
            lblPeso.ForeColor = Color.FromArgb(105, 115, 130);
            lblPeso.Location = new Point(290, 249);
            lblPeso.Name = "lblPeso";
            lblPeso.Size = new Size(30, 15);
            lblPeso.TabIndex = 13;
            lblPeso.Text = "PHP";
            // 
            // btnCreate
            // 
            btnCreate.BackColor = Color.FromArgb(23, 93, 186);
            btnCreate.Cursor = Cursors.Hand;
            btnCreate.DialogResult = DialogResult.OK;
            btnCreate.FlatAppearance.BorderSize = 0;
            btnCreate.FlatStyle = FlatStyle.Flat;
            btnCreate.Font = new Font("Segoe UI Semibold", 10.5F);
            btnCreate.ForeColor = Color.White;
            btnCreate.Location = new Point(18, 294);
            btnCreate.Margin = new Padding(3, 2, 3, 2);
            btnCreate.Name = "btnCreate";
            btnCreate.Size = new Size(158, 30);
            btnCreate.TabIndex = 14;
            btnCreate.Text = "Add application";
            btnCreate.UseVisualStyleBackColor = false;
            btnCreate.Click += btnCreate_Click;
            // 
            // btnCancel
            // 
            btnCancel.BackColor = Color.FromArgb(233, 236, 241);
            btnCancel.Cursor = Cursors.Hand;
            btnCancel.DialogResult = DialogResult.Cancel;
            btnCancel.FlatAppearance.BorderSize = 0;
            btnCancel.FlatStyle = FlatStyle.Flat;
            btnCancel.Font = new Font("Segoe UI", 10.5F);
            btnCancel.ForeColor = Color.FromArgb(50, 55, 65);
            btnCancel.Location = new Point(186, 294);
            btnCancel.Margin = new Padding(3, 2, 3, 2);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(96, 30);
            btnCancel.TabIndex = 15;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = false;
            // 
            // lblPhotoTitle
            // 
            lblPhotoTitle.AutoSize = true;
            lblPhotoTitle.Font = new Font("Segoe UI Semibold", 9.25F);
            lblPhotoTitle.ForeColor = Color.FromArgb(45, 52, 66);
            lblPhotoTitle.Location = new Point(341, 45);
            lblPhotoTitle.Name = "lblPhotoTitle";
            lblPhotoTitle.Size = new Size(92, 17);
            lblPhotoTitle.TabIndex = 16;
            lblPhotoTitle.Text = "2x2 ID picture";
            // 
            // picPhoto
            // 
            picPhoto.BackColor = Color.White;
            picPhoto.BorderStyle = BorderStyle.FixedSingle;
            picPhoto.Location = new Point(341, 62);
            picPhoto.Margin = new Padding(3, 2, 3, 2);
            picPhoto.Name = "picPhoto";
            picPhoto.Size = new Size(158, 136);
            picPhoto.SizeMode = PictureBoxSizeMode.Zoom;
            picPhoto.TabIndex = 17;
            picPhoto.TabStop = false;
            // 
            // btnPhoto
            // 
            btnPhoto.BackColor = Color.FromArgb(233, 236, 241);
            btnPhoto.Cursor = Cursors.Hand;
            btnPhoto.FlatAppearance.BorderSize = 0;
            btnPhoto.FlatStyle = FlatStyle.Flat;
            btnPhoto.ForeColor = Color.FromArgb(50, 55, 65);
            btnPhoto.Location = new Point(341, 202);
            btnPhoto.Margin = new Padding(3, 2, 3, 2);
            btnPhoto.Name = "btnPhoto";
            btnPhoto.Size = new Size(158, 22);
            btnPhoto.TabIndex = 18;
            btnPhoto.Text = "Choose photo...";
            btnPhoto.UseVisualStyleBackColor = false;
            btnPhoto.Click += btnPhoto_Click;
            // 
            // ofdPhoto
            // 
            ofdPhoto.Filter = "Image files (*.jpg, *.png, *.bmp)|*.jpg;*.jpeg;*.png;*.bmp";
            ofdPhoto.Title = "Choose 2x2 picture";
            // 
            // AdminApplicationForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(525, 339);
            Controls.Add(lblTitle);
            Controls.Add(lblName);
            Controls.Add(txtFullName);
            Controls.Add(lblStudentNumber);
            Controls.Add(txtStudentNumber);
            Controls.Add(lblEmail);
            Controls.Add(txtEmail);
            Controls.Add(lblProgram);
            Controls.Add(cboProgram);
            Controls.Add(lblGwa);
            Controls.Add(nudGwa);
            Controls.Add(lblIncome);
            Controls.Add(nudIncome);
            Controls.Add(lblPeso);
            Controls.Add(btnCreate);
            Controls.Add(btnCancel);
            Controls.Add(lblPhotoTitle);
            Controls.Add(picPhoto);
            Controls.Add(btnPhoto);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(3, 2, 3, 2);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "AdminApplicationForm";
            StartPosition = FormStartPosition.CenterParent;
            Text = "New application";
            ((System.ComponentModel.ISupportInitialize)nudGwa).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudIncome).EndInit();
            ((System.ComponentModel.ISupportInitialize)picPhoto).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }


        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtFullName;
        private System.Windows.Forms.Label lblStudentNumber;
        private System.Windows.Forms.TextBox txtStudentNumber;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblProgram;
        private System.Windows.Forms.ComboBox cboProgram;
        private System.Windows.Forms.Label lblGwa;
        private System.Windows.Forms.NumericUpDown nudGwa;
        private System.Windows.Forms.Label lblIncome;
        private System.Windows.Forms.NumericUpDown nudIncome;
        private System.Windows.Forms.Label lblPeso;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblPhotoTitle;
        private System.Windows.Forms.PictureBox picPhoto;
        private System.Windows.Forms.Button btnPhoto;
        private System.Windows.Forms.OpenFileDialog ofdPhoto;
    }
}
