﻿namespace scholarship_Application.Forms
{
    partial class SignUpForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pnlBanner = new Panel();
            label11 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            pnlMain = new Panel();
            lblError = new Label();
            lnkSignIn = new LinkLabel();
            label10 = new Label();
            btnCreateAccount = new Button();
            txtConfirmPassword = new TextBox();
            txtPassword = new TextBox();
            txtEmail = new TextBox();
            txtUsername = new TextBox();
            txtStudentNumber = new TextBox();
            chkShowPassword = new CheckBox();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            lblSubtitle = new Label();
            lblTitle = new Label();
            lblBrand = new Label();
            label2 = new Label();
            label1 = new Label();
            txtFullName = new TextBox();
            label12 = new Label();
            pnlBanner.SuspendLayout();
            pnlMain.SuspendLayout();
            SuspendLayout();
            // 
            // pnlBanner
            // 
            pnlBanner.BackColor = Color.FromArgb(24, 41, 74);
            pnlBanner.Controls.Add(label12);
            pnlBanner.Controls.Add(label11);
            pnlBanner.Controls.Add(label5);
            pnlBanner.Controls.Add(label4);
            pnlBanner.Controls.Add(label3);
            pnlBanner.Dock = DockStyle.Right;
            pnlBanner.Location = new Point(600, 0);
            pnlBanner.MaximumSize = new Size(236, 0);
            pnlBanner.Name = "pnlBanner";
            pnlBanner.Size = new Size(200, 450);
            pnlBanner.TabIndex = 0;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.ForeColor = Color.FromArgb(224, 224, 224);
            label11.Location = new Point(26, 232);
            label11.Name = "label11";
            label11.Size = new Size(104, 15);
            label11.TabIndex = 41;
            label11.Text = "chance to finish";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.ForeColor = Color.FromArgb(224, 224, 224);
            label5.Location = new Point(26, 209);
            label5.Name = "label5";
            label5.Size = new Size(110, 15);
            label5.TabIndex = 40;
            label5.Text = "student deserves a";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.ForeColor = Color.FromArgb(224, 224, 224);
            label4.Location = new Point(26, 186);
            label4.Name = "label4";
            label4.Size = new Size(91, 15);
            label4.TabIndex = 39;
            label4.Text = "Every Tarlaceno ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 16F, FontStyle.Bold);
            label3.ForeColor = Color.White;
            label3.Location = new Point(26, 146);
            label3.Name = "label3";
            label3.Size = new Size(114, 30);
            label3.TabIndex = 0;
            label3.Text = "Tarlac City";
            // 
            // pnlMain
            // 
            pnlMain.BackColor = Color.White;
            pnlMain.Controls.Add(lblError);
            pnlMain.Controls.Add(lnkSignIn);
            pnlMain.Controls.Add(label10);
            pnlMain.Controls.Add(btnCreateAccount);
            pnlMain.Controls.Add(txtConfirmPassword);
            pnlMain.Controls.Add(txtPassword);
            pnlMain.Controls.Add(txtEmail);
            pnlMain.Controls.Add(txtUsername);
            pnlMain.Controls.Add(txtStudentNumber);
            pnlMain.Controls.Add(chkShowPassword);
            pnlMain.Controls.Add(label9);
            pnlMain.Controls.Add(label8);
            pnlMain.Controls.Add(label7);
            pnlMain.Controls.Add(label6);
            pnlMain.Controls.Add(lblSubtitle);
            pnlMain.Controls.Add(lblTitle);
            pnlMain.Controls.Add(lblBrand);
            pnlMain.Controls.Add(label2);
            pnlMain.Controls.Add(label1);
            pnlMain.Controls.Add(txtFullName);
            pnlMain.Dock = DockStyle.Fill;
            pnlMain.Location = new Point(0, 0);
            pnlMain.Name = "pnlMain";
            pnlMain.Size = new Size(600, 450);
            pnlMain.TabIndex = 1;
            // 
            // lblError
            // 
            lblError.AutoSize = true;
            lblError.ForeColor = Color.FromArgb(199, 56, 56);
            lblError.Location = new Point(50, 351);
            lblError.Name = "lblError";
            lblError.Size = new Size(0, 15);
            lblError.TabIndex = 38;
            // 
            // lnkSignIn
            // 
            lnkSignIn.AutoSize = true;
            lnkSignIn.Location = new Point(273, 402);
            lnkSignIn.Name = "lnkSignIn";
            lnkSignIn.Size = new Size(43, 15);
            lnkSignIn.TabIndex = 8;
            lnkSignIn.TabStop = true;
            lnkSignIn.Text = "Sign In";
            lnkSignIn.LinkClicked += lnkSignIn_LinkClicked;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.ForeColor = Color.FromArgb(105, 115, 130);
            label10.Location = new Point(125, 402);
            label10.Name = "label10";
            label10.Size = new Size(142, 15);
            label10.TabIndex = 36;
            label10.Text = "Already have an account?";
            // 
            // btnCreateAccount
            // 
            btnCreateAccount.BackColor = Color.FromArgb(23, 93, 186);
            btnCreateAccount.FlatAppearance.BorderSize = 0;
            btnCreateAccount.FlatStyle = FlatStyle.Flat;
            btnCreateAccount.ForeColor = Color.White;
            btnCreateAccount.Location = new Point(50, 369);
            btnCreateAccount.Name = "btnCreateAccount";
            btnCreateAccount.Size = new Size(313, 30);
            btnCreateAccount.TabIndex = 7;
            btnCreateAccount.Text = "Create Account";
            btnCreateAccount.UseVisualStyleBackColor = false;
            btnCreateAccount.Click += btnCreateAccount_Click;
            // 
            // txtConfirmPassword
            // 
            txtConfirmPassword.Location = new Point(220, 302);
            txtConfirmPassword.Name = "txtConfirmPassword";
            txtConfirmPassword.Size = new Size(143, 23);
            txtConfirmPassword.TabIndex = 5;
            txtConfirmPassword.UseSystemPasswordChar = true;
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(50, 302);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(164, 23);
            txtPassword.TabIndex = 4;
            txtPassword.UseSystemPasswordChar = true;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(52, 258);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(311, 23);
            txtEmail.TabIndex = 3;
            // 
            // txtUsername
            // 
            txtUsername.Location = new Point(220, 209);
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(143, 23);
            txtUsername.TabIndex = 2;
            // 
            // txtStudentNumber
            // 
            txtStudentNumber.Location = new Point(52, 209);
            txtStudentNumber.Name = "txtStudentNumber";
            txtStudentNumber.Size = new Size(162, 23);
            txtStudentNumber.TabIndex = 1;
            // 
            // chkShowPassword
            // 
            chkShowPassword.AutoSize = true;
            chkShowPassword.Font = new Font("Segoe UI", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            chkShowPassword.ForeColor = Color.FromArgb(105, 115, 130);
            chkShowPassword.Location = new Point(50, 331);
            chkShowPassword.Name = "chkShowPassword";
            chkShowPassword.Size = new Size(108, 17);
            chkShowPassword.TabIndex = 6;
            chkShowPassword.Text = "Show password";
            chkShowPassword.UseVisualStyleBackColor = true;
            chkShowPassword.CheckedChanged += chkShowPassword_CheckedChanged;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(220, 284);
            label9.Name = "label9";
            label9.Size = new Size(107, 15);
            label9.TabIndex = 28;
            label9.Text = "Confirm Password:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(50, 284);
            label8.Name = "label8";
            label8.Size = new Size(60, 15);
            label8.TabIndex = 27;
            label8.Text = "Password:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(50, 235);
            label7.Name = "label7";
            label7.Size = new Size(39, 15);
            label7.TabIndex = 26;
            label7.Text = "Email:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(220, 186);
            label6.Name = "label6";
            label6.Size = new Size(63, 15);
            label6.TabIndex = 25;
            label6.Text = "Username:";
            // 
            // lblSubtitle
            // 
            lblSubtitle.AutoSize = true;
            lblSubtitle.ForeColor = Color.FromArgb(105, 115, 130);
            lblSubtitle.Location = new Point(52, 89);
            lblSubtitle.Name = "lblSubtitle";
            lblSubtitle.Size = new Size(251, 15);
            lblSubtitle.TabIndex = 24;
            lblSubtitle.Text = "Register as a student to apply for a scholarship";
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 21F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTitle.ForeColor = Color.FromArgb(24, 41, 74);
            lblTitle.Location = new Point(50, 51);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(217, 38);
            lblTitle.TabIndex = 23;
            lblTitle.Text = "Create Account";
            // 
            // lblBrand
            // 
            lblBrand.AutoSize = true;
            lblBrand.BackColor = Color.Transparent;
            lblBrand.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblBrand.ForeColor = Color.FromArgb(23, 93, 186);
            lblBrand.Location = new Point(50, 36);
            lblBrand.Name = "lblBrand";
            lblBrand.Size = new Size(144, 15);
            lblBrand.TabIndex = 22;
            lblBrand.Text = "City Government of Tarlac";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(50, 186);
            label2.Name = "label2";
            label2.Size = new Size(98, 15);
            label2.TabIndex = 21;
            label2.Text = "Student Number:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(50, 128);
            label1.Name = "label1";
            label1.Size = new Size(67, 15);
            label1.TabIndex = 20;
            label1.Text = "Full Name:";
            // 
            // txtFullName
            // 
            txtFullName.Location = new Point(52, 155);
            txtFullName.Name = "txtFullName";
            txtFullName.Size = new Size(311, 23);
            txtFullName.TabIndex = 0;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.ForeColor = Color.FromArgb(224, 224, 224);
            label12.Location = new Point(26, 258);
            label12.Name = "label12";
            label12.Size = new Size(45, 15);
            label12.TabIndex = 42;
            label12.Text = "school.";
            // 
            // SignUpForm
            // 
            AcceptButton = btnCreateAccount;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(pnlMain);
            Controls.Add(pnlBanner);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MinimumSize = new Size(718, 450);
            Name = "SignUpForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Tarlac City Government Scholarship System";
            pnlBanner.ResumeLayout(false);
            pnlBanner.PerformLayout();
            pnlMain.ResumeLayout(false);
            pnlMain.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel pnlBanner;
        private Panel pnlMain;
        private LinkLabel lnkSignIn;
        private Label label10;
        private Button btnCreateAccount;
        private TextBox txtConfirmPassword;
        private TextBox txtPassword;
        private TextBox txtEmail;
        private TextBox txtUsername;
        private TextBox txtStudentNumber;
        private CheckBox chkShowPassword;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label lblSubtitle;
        private Label lblTitle;
        private Label lblBrand;
        private Label label2;
        private Label label1;
        private TextBox txtFullName;
        private Label lblError;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label11;
        private Label label12;
    }
}