
using scholarship_Application.Models;

namespace scholarship_Application.Forms
{
    public partial class AdminApplicationForm : Form
    {
        public AdminApplicationForm()
        {
            InitializeComponent();

            nudIncome.Maximum = 10000000;

            cboProgram.SelectedIndex = 0;
            txtEmail.Focus();
        }

        public ScholarshipApplication? NewApplication { get; private set; }

        private void btnPhoto_Click(object sender, EventArgs e)
        {
            if (ofdPhoto.ShowDialog(this) != DialogResult.OK)
            {
                return;
            }

            try
            {
                picPhoto.Image?.Dispose();
                picPhoto.Image = Image.FromFile(ofdPhoto.FileName);
            }
            catch
            {
                MessageBox.Show(this, "That file is not a valid image.",
                    "Invalid picture", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            NewApplication = new ScholarshipApplication
            {
                FullName = "",
                StudentNumber = "",
                Email = "",
                ScholarshipType = cboProgram.SelectedItem?.ToString() ?? "Merit",
                Gpa = nudGwa.Value,
                AnnualIncome = nudIncome.Value,
                Status = "Submitted",
                Remarks = "",
                SubmittedAt = DateTime.Now,
                Photo = picPhoto.Image is null ? null : new Bitmap(picPhoto.Image),
            };

            if (string.IsNullOrWhiteSpace(txtFullName.Text))
            {
                NewApplication.FullName = "Unnamed applicant";
            }
            else
            {
                NewApplication.FullName = txtFullName.Text.Trim();
            }

            if (string.IsNullOrWhiteSpace(txtStudentNumber.Text))
            {
                NewApplication.StudentNumber = $"2023-{Random.Shared.Next(100, 9999):0000}";
            }
            else
            {
                NewApplication.StudentNumber = txtStudentNumber.Text.Trim();
            }

            if (string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                NewApplication.Email = "not.provided@tarlac.gov.ph";
            }
            else
            {
                NewApplication.Email = txtEmail.Text.Trim();
            }
        }

        private void nudIncome_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
