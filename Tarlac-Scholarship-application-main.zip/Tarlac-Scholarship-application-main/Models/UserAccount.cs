﻿namespace scholarship_Application.Models
{
    public static class Roles
    {
        public const string Student = "Student";
        public const string Admin = "Admin";
    }

    public class UserAccount
    {
        public string Username { get; set; } = "";
        public string FullName { get; set; } = "";
        public string StudentNumber { get; set; } = "";
        public string Email { get; set; } = "";
        public string PasswordHash { get; set; } = "";
        public string Role { get; set; } = Roles.Student;
        public DateTime CreatedAt { get; set; }
    }
}
