﻿using System.Text.Json;
using scholarship_Application.Models;

namespace scholarship_Application.Services
{
    // Saves accounts to %AppData%\TarlacScholarship\users.json
    public class JsonUserRepository : IUserRepository
    {
        private static readonly JsonSerializerOptions Options = new() { WriteIndented = true };

        private readonly string _path;
        private readonly List<UserAccount> _users;

        public JsonUserRepository()
        {
            string folder = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "TarlacScholarship");
            Directory.CreateDirectory(folder);
            _path = Path.Combine(folder, "users.json");

            _users = File.Exists(_path) ? Load() : new List<UserAccount>();

            if (!_users.Any(u => u.Role == Roles.Admin))
            {
                _users.Add(CreateDefaultAdmin());
                Save();
            }
        }

        public UserAccount? FindByUsername(string username) =>
            _users.FirstOrDefault(u => string.Equals(u.Username, username, StringComparison.OrdinalIgnoreCase));

        public UserAccount? FindByEmail(string email) =>
            _users.FirstOrDefault(u => string.Equals(u.Email, email, StringComparison.OrdinalIgnoreCase));

        public UserAccount? FindByStudentNumber(string studentNumber) =>
            _users.FirstOrDefault(u =>
                u.StudentNumber.Length > 0 &&
                string.Equals(u.StudentNumber, studentNumber, StringComparison.OrdinalIgnoreCase));

        public void Add(UserAccount account)
        {
            _users.Add(account);
            Save();
        }

        private List<UserAccount> Load()
        {
            try
            {
                string json = File.ReadAllText(_path);
                return JsonSerializer.Deserialize<List<UserAccount>>(json) ?? new List<UserAccount>();
            }
            catch (Exception ex) when (ex is IOException or JsonException or UnauthorizedAccessException)
            {
                return new List<UserAccount>();
            }
        }

        private void Save()
        {
            File.WriteAllText(_path, JsonSerializer.Serialize(_users, Options));
        }

        private static UserAccount CreateDefaultAdmin() => new()
        {
            Username = "admin",
            FullName = "Scholarship Administrator",
            Email = "admin@tarlac.gov.ph",
            PasswordHash = PasswordHasher.Hash("Admin@123"),
            Role = Roles.Admin,
            CreatedAt = DateTime.Now,
        };
    }
}
