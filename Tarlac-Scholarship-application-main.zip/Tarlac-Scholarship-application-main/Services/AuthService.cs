﻿using System.Net.Mail;
using System.Text.RegularExpressions;
using scholarship_Application.Models;

namespace scholarship_Application.Services
{
    public record RegisterResult(bool Success, string Message = "", string Field = "");

    public static class AuthService
    {
        // Change this one line to switch to a database later.
        private static readonly IUserRepository Users = new JsonUserRepository();

        private static readonly Regex UsernameRule = new("^[A-Za-z0-9._]{4,20}$");

        public static RegisterResult Register(
            string fullName,
            string studentNumber,
            string username,
            string email,
            string password,
            string confirmPassword)
        {
            fullName = fullName.Trim();
            studentNumber = studentNumber.Trim();
            username = username.Trim();
            email = email.Trim();

            if (fullName.Length < 2)
            {
                return Fail("FullName", "Enter your full name.");
            }

            if (studentNumber.Length < 4 || !studentNumber.All(c => char.IsLetterOrDigit(c) || c == '-'))
            {
                return Fail("StudentNumber", "Enter a valid student number (letters, numbers and dashes only).");
            }

            if (!UsernameRule.IsMatch(username))
            {
                return Fail("Username", "Username must be 4 to 20 characters: letters, numbers, dots or underscores.");
            }

            if (username.StartsWith("admin", StringComparison.OrdinalIgnoreCase))
            {
                return Fail("Username", "That username isn't available. Try another.");
            }

            if (!IsValidEmail(email))
            {
                return Fail("Email", "Enter a valid email address.");
            }

            if (password.Length < 8 || !password.Any(char.IsLetter) || !password.Any(char.IsDigit))
            {
                return Fail("Password", "Password needs at least 8 characters, with letters and numbers.");
            }

            if (password != confirmPassword)
            {
                return Fail("Confirm", "Passwords do not match.");
            }

            if (Users.FindByUsername(username) is not null)
            {
                return Fail("Username", "That username is already taken.");
            }

            if (Users.FindByStudentNumber(studentNumber) is not null)
            {
                return Fail("StudentNumber", "That student number already has an account.");
            }

            if (Users.FindByEmail(email) is not null)
            {
                return Fail("Email", "That email is already registered.");
            }

            try
            {
                Users.Add(new UserAccount
                {
                    Username = username,
                    FullName = fullName,
                    StudentNumber = studentNumber,
                    Email = email,
                    PasswordHash = PasswordHasher.Hash(password),
                    Role = Roles.Student,
                    CreatedAt = DateTime.Now,
                });
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
            {
                return Fail("", "Couldn't save your account. Try again.");
            }

            return new RegisterResult(true);
        }

        public static UserAccount? SignIn(string usernameOrEmail, string password)
        {
            string id = usernameOrEmail.Trim();
            UserAccount? user = Users.FindByUsername(id) ?? Users.FindByEmail(id);

            if (user is null || !PasswordHasher.Verify(password, user.PasswordHash))
            {
                return null;
            }

            Session.CurrentUser = user;
            return user;
        }

        public static void SignOut() => Session.CurrentUser = null;

        private static RegisterResult Fail(string field, string message) =>
            new(false, message, field);

        private static bool IsValidEmail(string email) =>
            MailAddress.TryCreate(email, out MailAddress? address)
            && address.Address == email
            && address.Host.Contains('.');
    }
}
