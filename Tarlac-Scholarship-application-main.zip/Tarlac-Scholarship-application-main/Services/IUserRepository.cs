﻿using scholarship_Application.Models;

namespace scholarship_Application.Services
{
    // The rest of the app only talks to this interface.
    // To use a database later, write a new class that implements it
    // (for example SqlUserRepository) and change one line in AuthService.
    public interface IUserRepository
    {
        UserAccount? FindByUsername(string username);

        UserAccount? FindByEmail(string email);

        UserAccount? FindByStudentNumber(string studentNumber);

        void Add(UserAccount account);
    }
}
