﻿using scholarship_Application.Models;

namespace scholarship_Application.Services
{
    public static class Session
    {
        public static UserAccount? CurrentUser { get; set; }

        public static string FullName => CurrentUser?.FullName ?? "";

        public static string StudentNumber => CurrentUser?.StudentNumber ?? "";
    }
}
